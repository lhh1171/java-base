//package com.cjs.sso.repository;
//
//import com.cjs.sso.entity.SysUserRole;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
//
//import java.util.List;
//
///**
// * @author ChengJianSheng
// * @date 2019-02-12
// */
//public interface SysUserRoleRepository extends JpaSpecificationExecutor<SysUserRole>, JpaRepository<SysUserRole, Integer> {
//
//    List<SysUserRole> findByUserId(Integer userId);
//}
