package error;

public enum Requesterror {
    TabName_error,Method_Error;
}
