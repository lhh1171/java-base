package interfaces;

public class Constans {

    String FAVICON_ICO="/favicon.ico";
    String CONTENT_TYPE="Content-Type";
    String JSON ="application/json";
    String FORM="application/x-www-form-urlencoded";
    String MULTI_PART="multipart/form-data";

}
